// pages/indexList/indexList.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    heightRpx:'',
    tabId:1,
    mbModal:false,
    
  },
  memberTap:function(e){
    this.setData({
      mbModal: true
    })
  },
  cancelTap: function (e) {
    this.setData({
      mbModal: false
    })
  },
  confirmTap:function(e){
    wx.navigateTo({
      url: '/pages/indexMbOpen/indexMbOpen'
    })
    this.setData({
      mbModal: false
    });
  },
  tabTap:function(e){
    console.log(e.target.dataset.id);
    this.setData({
      tabId: e.target.dataset.id
    })
  },
  musicTap: function (e) {
    wx.navigateTo({
      url: '/pages/indexPlay/indexPlay',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.getSystemInfo({
      success: function(res) {
        console.log(res.windowHeight);
        var clientH = res.windowHeight,
          clientW = res.windowWidth,
          rpxR = 750 / clientW;
        var calcH = clientH * rpxR-98;
        that.setData({
          heightRpx: calcH
        })
      },
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})