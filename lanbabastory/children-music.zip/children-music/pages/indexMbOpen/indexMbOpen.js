// pages/indexList/indexList.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    heightRpx:'',
    tabId:1,
    mbId:0,
    timePrice: ['48元/3个月(送38元优惠劵）', '48元/3个月(送38元优惠劵）','48元/3个月(送38元优惠劵）']
    
  },
  memberTap:function(e){
    this.setData({
      mbId: e.detail.value
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.getSystemInfo({
      success: function(res) {
        console.log(res.windowHeight);
        var clientH = res.windowHeight,
          clientW = res.windowWidth,
          rpxR = 750 / clientW;
        var calcH = clientH * rpxR-98;
        that.setData({
          heightRpx: calcH
        })
      },
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})