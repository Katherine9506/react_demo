// pages/indexSearch/indexSearch.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bgcolor: ['#A3F5C2', '#EDE8C0', '#A3B7F5', '#A3F5C2', '#A3F5C2', '#A3F5C2',],
    recommendList:[
      { name: '三字经', bgColor: '#A3F5C2'},
      { name: '诗词五百首', bgColor: '#EDE8C0' },
      { name: '小红帽', bgColor: '#A3B7F5' },
      { name: '格林童话' },
      { name: '白雪公主'},
      { name: '七个小矮人'},
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})