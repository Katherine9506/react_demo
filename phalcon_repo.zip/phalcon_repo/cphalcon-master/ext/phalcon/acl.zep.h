
extern zend_class_entry *phalcon_acl_ce;

ZEPHIR_INIT_CLASS(Phalcon_Acl);

